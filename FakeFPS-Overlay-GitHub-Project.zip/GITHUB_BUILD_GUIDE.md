# HƯỚNG DẪN BUILD APP FAKE FPS QUA GITHUB ACTIONS (100% THÀNH CÔNG)

Chào bạn! Dự án này đã được cấu hình sẵn toàn bộ **GitHub Actions CI/CD** (`.github/workflows/build-apk.yml`). Bạn không cần cài đặt Android Studio hay máy tính mạnh, GitHub sẽ tự động compile ra file APK trong đám mây miễn phí!

---

## BƯỚC 1: TẢI SOURCE CODE VỀ MÁY
1. Bấm nút **"Tải Trọn Bộ Mã Nguồn (.ZIP)"** trên giao diện web này.
2. Giải nén file zip ra một thư mục trên máy bạn.

---

## BƯỚC 2: TẠO REPOSITORY TRÊN GITHUB
1. Truy cập [https://github.com](https://github.com) và đăng nhập (hoặc tạo tài khoản miễn phí).
2. Nhấp dấu **+** ở góc trên cùng bên phải -> Chọn **New repository**.
3. Đặt tên Repo: `fake-fps-overlay` (hoặc bất kỳ tên nào bạn thích).
4. Bạn có thể chọn **Public** hoặc **Private** đều được!
5. Bấm **Create repository**.

---

## BƯỚC 3: ĐẨY CODE LÊN GITHUB (2 CÁCH DỄ DÀNG)

### Cách A: Kéo thả trực tiếp trên trình duyệt (Dễ nhất - Không cần cài Git)
1. Trong trang repository vừa tạo trên GitHub, bấm **"uploading an existing file"**.
2. Kéo toàn bộ file và thư mục vừa giải nén (bao gồm cả thư mục `.github`, `app`, `gradle`, `build.gradle`...) thả vào ô tải lên.
3. Chờ trình duyệt upload xong -> Nhập ghi chú commit -> Bấm **Commit changes**.

### Cách B: Dùng lệnh Git Terminal
Mở terminal trong thư mục vừa giải nén và chạy:
```bash
git init
git add .
git commit -m "Initial Fake FPS Overlay project"
git branch -M main
git remote add origin https://github.com/TÊN_GITHUB_CỦA_BẠN/fake-fps-overlay.git
git push -u origin main
```

---

## BƯỚC 4: LẤY FILE APK ĐÃ COMPILE TỪ GITHUB ACTIONS
1. Trên trang repo GitHub của bạn, nhấp vào tab **Actions** (ở thanh trên cùng cạnh Code, Issues, Pull requests).
2. Bạn sẽ thấy một workflow có tên **"Build Fake FPS APK"** đang chạy (có icon màu vàng quay).
3. Đợi khoảng **1 đến 2 phút**, khi icon chuyển sang **màu xanh lá cây dấu tích ✅ (Success)**:
   - Nhấp vào dòng workflow đó.
   - Kéo xuống mục **Artifacts** ở dưới cùng.
   - Nhấp vào **FakeFPS-Overlay-v1.0-Debug** để tải file APK về điện thoại!

---

## BƯỚC 5: CÀI ĐẶT LÊN ĐIỆN THOẠI ANDROID & BẬT
1. Mở file `app-debug.apk` vừa tải về điện thoại và chọn **Cài đặt**.
2. Mở ứng dụng **Fake FPS Overlay**:
   - Bấm **"1. Cấp Quyền Cửa Sổ Nổi"**: Điện thoại sẽ mở Cài đặt hệ thống, hãy tìm tên app và gạt công tắc **Cho phép hiển thị trên các ứng dụng khác (SYSTEM_ALERT_WINDOW)**.
   - Quay lại app -> Bấm **"2. Bật Cửa Sổ Nổi FPS"**.
3. Cửa sổ hiển thị FPS sẽ xuất hiện ngay trên màn hình!
   - Bạn có thể dùng ngón tay **kéo thả vị trí** tới bất kỳ góc nào bạn muốn.
   - Mở Free Fire, PUBG, TikTok, YouTube... số FPS vẫn hiển thị nổi mượt mà ở trên cùng!

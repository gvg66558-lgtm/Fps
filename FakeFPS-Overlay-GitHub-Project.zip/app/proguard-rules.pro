# Proguard rules
-keep class com.example.fakefps.** { *; }
-dontwarn com.example.fakefps.**

package com.example.fakefps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import java.util.Locale
import kotlin.math.sin
import kotlin.random.Random

/**
 * FloatingFpsService
 * Dịch vụ Foreground hiển thị chỉ số FPS nổi trên màn hình mọi game (Free Fire, PUBG, Genshin...)
 */
class FloatingFpsService : Service() {

    companion object {
        const val TAG = "FloatingFpsService"
        const val CHANNEL_ID = "FloatingFpsChannel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_UPDATE_CONFIG = "ACTION_UPDATE_CONFIG"

        var isRunning = false
            private set
    }

    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null
    private lateinit var layoutParams: WindowManager.LayoutParams
    private lateinit var prefs: SharedPreferences

    private val handler = Handler(Looper.getMainLooper())
    private var updateRunnable: Runnable? = null

    // Cấu hình FPS hiện tại
    private var targetFps = 146
    private var jitterMode = "realistic" // "locked", "realistic", "combat_drop", "lag_spikes"
    private var jitterAmount = 1.5f
    private var showDecimals = false
    private var showPing = true
    private var pingValue = 18
    private var showTemp = true
    private var tempValue = 42
    private var refreshRateMs = 250L
    private var textColorHex = "#22c55e"
    private var bgOpacity = 85 // 0 - 100

    private var tickCount = 0
    private var combatDropActive = false
    private var combatDropDuration = 0

    // Views bên trong overlay
    private var tvFpsValue: TextView? = null
    private var tvFpsUnit: TextView? = null
    private var tvPing: TextView? = null
    private var tvTemp: TextView? = null
    private var rootContainer: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("fake_fps_prefs", Context.MODE_PRIVATE)
        loadPreferences()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        initFloatingWindow()
        startFpsSimulationLoop()
        isRunning = true
        Log.i(TAG, "FloatingFpsService started successfully")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
            }
            ACTION_UPDATE_CONFIG -> {
                loadPreferences()
                applyVisualStyles()
            }
        }
        return START_STICKY
    }

    private fun loadPreferences() {
        targetFps = prefs.getInt("target_fps", 146)
        jitterMode = prefs.getString("jitter_mode", "realistic") ?: "realistic"
        jitterAmount = prefs.getFloat("jitter_amount", 1.5f)
        showDecimals = prefs.getBoolean("show_decimals", false)
        showPing = prefs.getBoolean("show_ping", true)
        pingValue = prefs.getInt("ping_value", 18)
        showTemp = prefs.getBoolean("show_temp", true)
        tempValue = prefs.getInt("temp_value", 42)
        refreshRateMs = prefs.getLong("refresh_rate_ms", 250L)
        textColorHex = prefs.getString("text_color", "#22c55e") ?: "#22c55e"
        bgOpacity = prefs.getInt("bg_opacity", 85)
    }

    private fun initFloatingWindow() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val inflater = LayoutInflater.from(this)
        floatingView = inflater.inflate(R.layout.layout_floating_fps, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Vị trí mặc định góc trên màn hình
            x = prefs.getInt("pos_x", 120)
            y = prefs.getInt("pos_y", 180)
        }

        bindViews()
        setupTouchAndDragListener()
        applyVisualStyles()

        try {
            windowManager.addView(floatingView, layoutParams)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to add floating view to window manager", e)
        }
    }

    private fun bindViews() {
        floatingView?.let { root ->
            rootContainer = root.findViewById(R.id.fps_root_container)
            tvFpsValue = root.findViewById(R.id.tv_fps_number)
            tvFpsUnit = root.findViewById(R.id.tv_fps_unit)
            tvPing = root.findViewById(R.id.tv_ping)
            tvTemp = root.findViewById(R.id.tv_temp)
        }
    }

    private fun applyVisualStyles() {
        try {
            val color = Color.parseColor(textColorHex)
            tvFpsValue?.setTextColor(color)
            tvFpsUnit?.setTextColor(color)

            // Áp dụng độ trong suốt nền bo tròn (Corner radius 12dp)
            val alpha = (bgOpacity * 255 / 100).coerceIn(0, 255)
            val bgDrawable = GradientDrawable().apply {
                setColor(Color.argb(alpha, 15, 23, 42)) // Slate 900
                cornerRadius = 24f
                setStroke(2, Color.argb((alpha * 0.8f).toInt(), 148, 163, 184))
            }
            rootContainer?.background = bgDrawable

            tvPing?.visibility = if (showPing) View.VISIBLE else View.GONE
            tvTemp?.visibility = if (showTemp) View.VISIBLE else View.GONE
        } catch (e: Exception) {
            Log.e(TAG, "Error applying styles", e)
        }
    }

    /**
     * Cho phép người dùng kéo thả (drag & drop) cửa sổ FPS tự do khắp màn hình
     */
    private fun setupTouchAndDragListener() {
        floatingView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isClick = false

            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                if (event == null) return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = layoutParams.x
                        initialY = layoutParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isClick = true
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - initialTouchX
                        val dy = event.rawY - initialTouchY
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                            isClick = false
                        }
                        layoutParams.x = (initialX + dx).toInt()
                        layoutParams.y = (initialY + dy).toInt()
                        windowManager.updateViewLayout(floatingView, layoutParams)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        // Lưu vị trí mới vào SharedPreferences
                        prefs.edit()
                            .putInt("pos_x", layoutParams.x)
                            .putInt("pos_y", layoutParams.y)
                            .apply()

                        if (isClick) {
                            // Chạm nhanh: mở lại MainActivity để đổi cài đặt
                            val appIntent = Intent(this@FloatingFpsService, MainActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            }
                            startActivity(appIntent)
                        }
                        return true
                    }
                }
                return false
            }
        })
    }

    /**
     * Vòng lặp mô phỏng chỉ số FPS chân thực với các thuật toán dao động
     */
    private fun startFpsSimulationLoop() {
        updateRunnable = object : Runnable {
            override fun run() {
                tickCount++
                val simulatedFps = calculateNextFps()
                val simulatedPing = (pingValue + Random.nextInt(-2, 3)).coerceAtLeast(5)
                val simulatedTemp = (tempValue + if (tickCount % 20 == 0) Random.nextInt(-1, 2) else 0).coerceIn(35, 65)

                // Cập nhật lên TextView
                if (showDecimals) {
                    tvFpsValue?.text = String.format(Locale.US, "%.1f", simulatedFps)
                } else {
                    tvFpsValue?.text = String.format(Locale.US, "%d", simulatedFps.toInt())
                }

                if (showPing) {
                    tvPing?.text = "${simulatedPing}ms"
                }
                if (showTemp) {
                    tvTemp?.text = "${simulatedTemp}°C"
                }

                handler.postDelayed(this, refreshRateMs)
            }
        }
        handler.post(updateRunnable!!)
    }

    private fun calculateNextFps(): Double {
        return when (jitterMode) {
            "locked" -> {
                // Khóa cứng ổn định tuyệt đối (±0.1 FPS)
                targetFps + (Random.nextDouble(-0.1, 0.1))
            }
            "combat_drop" -> {
                // Thỉnh thoảng tụt khung hình khi giao tranh
                if (!combatDropActive && tickCount % 40 == 0 && Random.nextBoolean()) {
                    combatDropActive = true
                    combatDropDuration = Random.nextInt(6, 14)
                }
                if (combatDropActive) {
                    combatDropDuration--
                    if (combatDropDuration <= 0) combatDropActive = false
                    val dropPct = 0.15 + (Random.nextDouble(0.05, 0.15))
                    (targetFps * (1.0 - dropPct)) + Random.nextDouble(-1.5, 1.5)
                } else {
                    targetFps + Random.nextDouble(-0.8, 0.8)
                }
            }
            "lag_spikes" -> {
                // Giật lag bất thường
                if (Random.nextInt(10) == 0) {
                    (targetFps * 0.4) + Random.nextDouble(0.0, 10.0)
                } else {
                    targetFps + Random.nextDouble(-jitterAmount.toDouble(), jitterAmount.toDouble())
                }
            }
            else -> {
                // "realistic": Dao động hình sin mềm mại + micro-noise tự nhiên
                val wave = sin(tickCount * 0.15) * (jitterAmount * 0.6)
                val noise = Random.nextDouble(-jitterAmount * 0.4, jitterAmount * 0.4)
                (targetFps + wave + noise).coerceAtLeast(1.0)
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Fake FPS Overlay Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Hiển thị chỉ số FPS nổi trên màn hình"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pOpenIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, FloatingFpsService::class.java).apply {
            action = ACTION_STOP
        }
        val pStopIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Fake FPS Overlay đang chạy")
            .setContentText("FPS mục tiêu: ${targetFps} FPS | Chạm vào cửa sổ để di chuyển")
            .setSmallIcon(R.drawable.ic_fps_notification)
            .setContentIntent(pOpenIntent)
            .addAction(R.drawable.ic_stop, "Tắt Overlay", pStopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        updateRunnable?.let { handler.removeCallbacks(it) }
        floatingView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                Log.e(TAG, "Error removing floating view", e)
            }
        }
        isRunning = false
        Log.i(TAG, "FloatingFpsService stopped")
    }
}

package com.example.fakefps

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {

    companion object {
        private const val OVERLAY_PERMISSION_REQ_CODE = 2001
    }

    private lateinit var prefs: SharedPreferences

    private lateinit var tvCurrentFps: TextView
    private lateinit var tvStatus: TextView
    private lateinit var btnToggleOverlay: Button
    private lateinit var btnGrantPermission: Button
    private lateinit var toggleTargetFps: MaterialButtonToggleGroup
    private lateinit var seekJitter: SeekBar
    private lateinit var tvJitterLabel: TextView
    private lateinit var switchDecimals: SwitchMaterial
    private lateinit var switchPing: SwitchMaterial
    private lateinit var switchTemp: SwitchMaterial

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("fake_fps_prefs", Context.MODE_PRIVATE)

        initViews()
        loadSavedConfig()
        setupListeners()
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun initViews() {
        tvCurrentFps = findViewById(R.id.tv_target_fps_display)
        tvStatus = findViewById(R.id.tv_service_status)
        btnToggleOverlay = findViewById(R.id.btn_toggle_overlay)
        btnGrantPermission = findViewById(R.id.btn_grant_permission)
        toggleTargetFps = findViewById(R.id.toggle_target_fps)
        seekJitter = findViewById(R.id.seek_jitter)
        tvJitterLabel = findViewById(R.id.tv_jitter_label)
        switchDecimals = findViewById(R.id.switch_decimals)
        switchPing = findViewById(R.id.switch_ping)
        switchTemp = findViewById(R.id.switch_temp)
    }

    private fun loadSavedConfig() {
        val targetFps = prefs.getInt("target_fps", 146)
        tvCurrentFps.text = "${targetFps} FPS"

        when (targetFps) {
            60 -> toggleTargetFps.check(R.id.btn_fps_60)
            90 -> toggleTargetFps.check(R.id.btn_fps_90)
            120 -> toggleTargetFps.check(R.id.btn_fps_120)
            144 -> toggleTargetFps.check(R.id.btn_fps_144)
            240 -> toggleTargetFps.check(R.id.btn_fps_240)
            else -> toggleTargetFps.check(R.id.btn_fps_120)
        }

        val jitter = prefs.getFloat("jitter_amount", 1.5f)
        seekJitter.progress = (jitter * 10).toInt()
        tvJitterLabel.text = "Độ dao động: ±${String.format("%.1f", jitter)} FPS"

        switchDecimals.isChecked = prefs.getBoolean("show_decimals", false)
        switchPing.isChecked = prefs.getBoolean("show_ping", true)
        switchTemp.isChecked = prefs.getBoolean("show_temp", true)
    }

    private fun setupListeners() {
        // Cấp quyền Cửa Sổ Nổi (SYSTEM_ALERT_WINDOW)
        btnGrantPermission.setOnClickListener {
            requestOverlayPermission()
        }

        // Bật / Dừng Dịch vụ
        btnToggleOverlay.setOnClickListener {
            if (!hasOverlayPermission()) {
                requestOverlayPermission()
                return@setOnClickListener
            }

            if (FloatingFpsService.isRunning) {
                stopFpsService()
            } else {
                startFpsService()
            }
        }

        // Chọn nhanh FPS mục tiêu (60, 90, 120, 144, 240)
        toggleTargetFps.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                val fps = when (checkedId) {
                    R.id.btn_fps_60 -> 60
                    R.id.btn_fps_90 -> 90
                    R.id.btn_fps_120 -> 120
                    R.id.btn_fps_144 -> 144
                    R.id.btn_fps_240 -> 240
                    else -> 120
                }
                prefs.edit().putInt("target_fps", fps).apply()
                tvCurrentFps.text = "${fps} FPS"
                notifyServiceUpdate()
            }
        }

        // Slider độ dao động
        seekJitter.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val jitter = progress / 10f
                tvJitterLabel.text = "Độ dao động: ±${String.format("%.1f", jitter)} FPS"
                if (fromUser) {
                    prefs.edit().putFloat("jitter_amount", jitter).apply()
                    notifyServiceUpdate()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Toggles
        switchDecimals.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("show_decimals", isChecked).apply()
            notifyServiceUpdate()
        }

        switchPing.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("show_ping", isChecked).apply()
            notifyServiceUpdate()
        }

        switchTemp.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("show_temp", isChecked).apply()
            notifyServiceUpdate()
        }
    }

    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Toast.makeText(this, "Vui lòng gạt BẬT quyền 'Hiển thị trên các ứng dụng khác'", Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, OVERLAY_PERMISSION_REQ_CODE)
        }
    }

    private fun startFpsService() {
        val intent = Intent(this, FloatingFpsService::class.java).apply {
            action = FloatingFpsService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        Toast.makeText(this, "Đã bật cửa sổ nổi FPS! Bạn có thể kéo thả tự do.", Toast.LENGTH_SHORT).show()
        updateStatus()
    }

    private fun stopFpsService() {
        val intent = Intent(this, FloatingFpsService::class.java).apply {
            action = FloatingFpsService.ACTION_STOP
        }
        stopService(intent)
        Toast.makeText(this, "Đã tắt cửa sổ nổi FPS", Toast.LENGTH_SHORT).show()
        updateStatus()
    }

    private fun notifyServiceUpdate() {
        if (FloatingFpsService.isRunning) {
            val intent = Intent(this, FloatingFpsService::class.java).apply {
                action = FloatingFpsService.ACTION_UPDATE_CONFIG
            }
            startService(intent)
        }
    }

    private fun updateStatus() {
        val permitted = hasOverlayPermission()
        if (!permitted) {
            tvStatus.text = "Chưa cấp quyền Cửa Sổ Nổi"
            tvStatus.setTextColor(getColor(android.R.color.holo_red_light))
            btnGrantPermission.isEnabled = true
            btnToggleOverlay.isEnabled = false
        } else {
            btnGrantPermission.isEnabled = false
            btnToggleOverlay.isEnabled = true
            if (FloatingFpsService.isRunning) {
                tvStatus.text = "Đang chạy đè trên màn hình"
                tvStatus.setTextColor(getColor(android.R.color.holo_green_light))
                btnToggleOverlay.text = "Tắt Cửa Sổ Nổi FPS"
                btnToggleOverlay.setBackgroundColor(getColor(android.R.color.holo_red_dark))
            } else {
                tvStatus.text = "Sẵn sàng (Đã cấp đủ quyền)"
                tvStatus.setTextColor(getColor(android.R.color.holo_blue_light))
                btnToggleOverlay.text = "Bật Cửa Sổ Nổi FPS"
                btnToggleOverlay.setBackgroundColor(getColor(R.color.accent_green))
            }
        }
    }
}

rootProject.name = "FakeFPSOverlay"
include(":app")
